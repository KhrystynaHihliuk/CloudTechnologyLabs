cp /home/site/wwwroot/nginx.conf /etc/nginx/sites-available/default
service nginx reload